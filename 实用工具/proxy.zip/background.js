var config = {
  mode: "fixed_servers",
  rules: {
    singleProxy: {
      scheme: "http",
      host: "http-dyn.abuyun.com",
      port: 9020
    },
    bypassList: ["foobar.com"]
  }
};

chrome.proxy.settings.set({
  value: config,
  scope: "regular"
}, function () {});

function callbackFn(details) {
  return {
    authCredentials: {
      username: "H4069413V6797J9D",
      password: "FC20F1BDEAF3A3BC"
    }
  };
}

chrome.webRequest.onAuthRequired.addListener(
  callbackFn, {
    urls: ["<all_urls>"]
  },
  ['blocking']
);